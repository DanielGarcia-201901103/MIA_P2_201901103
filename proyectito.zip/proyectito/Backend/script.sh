clear
go build main.go
./main