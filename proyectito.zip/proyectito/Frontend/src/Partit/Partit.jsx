import { Link } from "react-router-dom";
import Navb from "../Nav/Navb.jsx";
import { useState, useRef } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Swal from 'sweetalert2';
const Partit = () => {

    const API_PORT = "localhost:5000"
    const [userLogged, setUserLogged] = useState(false);

    const formLogin2 = () => {
        Swal.fire({
            title: 'Reports Login',
            html: `<input type="text" id="idPartition" class="swal2-input" placeholder="ID Particion">
          <input type="text" id="login" class="swal2-input" placeholder="Username">
          <input type="password" id="password" class="swal2-input" placeholder="Password">`,
            confirmButtonText: 'Sign in',
            focusConfirm: false,
            width: '600px',
            preConfirm: () => {
                const login = Swal.getPopup().querySelector('#login').value
                const password = Swal.getPopup().querySelector('#password').value
                const idPartition = Swal.getPopup().querySelector('#idPartition').value
                if (!login || !password || !idPartition) {
                    Swal.showValidationMessage(`Please enter ID Particion, login and password`)
                }
                return { login: login, password: password, idPartition: idPartition }
            }
        }).then((result) => {
            doLogin2(result);
            // Swal.fire(`
            //   Login: ${result.value.login}
            //   Password: ${result.value.password}
            //   Password: ${result.value.idPartition}
            // `.trim())
        })
    }

    const doLogin2 = (data) => {

        if (userLogged) {
            ale2("Tiene una sesión activa, cierre sesión para continuar");
            return;
        }

        const element = {
            id: data.value.idPartition,
            user: data.value.login,
            password: data.value.password
        }

        console.log(element);

        axios.post('http://' + API_PORT + '/loginFront', element).then(res => {
            if (res.data.message == "ok") {
                ale1("Bienvenido usuario: " + data.value.login);
                setUserLogged(true);

                let arrTemp = arrAux.map(item => {
                    return { value: item.graph, label: item.name }
                });

                setOptions(arrTemp);

            } else if (res.data.message == "usuario") {
                ale2("Usuario no encontrado");
            }
            else if (res.data.message == "fallida") {
                ale2("Autenticacion fallida");
            }
            else if (res.data.message == "particion") {
                ale2("No exite una particion montada con ese id");
            }
            else if (res.data.message == "logueado") {
                ale2("Existe un usuario logueado, cierre sesion para continuar");
            } else if (res.data.message == "ext") {
                ale2("La particion a la que intenta acceder no posee el formato ext2");
            }
            // setContentAST(res.data.graficaAst);
        }).catch(error => {
            notificacion("Ocurrio un error al realizar la petición")
            console.log(error);
        });
    }


  const doLogout = () => {
    
    if (userLogged)
    {
      setUserLogged(false);
      ale1("Se ha cerrado sesión correctamente");
      clearAST();
      setArrAux([]);
      setOptions([]);
    }
    else
    {  
      axios.get('http://'+API_PORT+'/logout').then(res => 
      { 
        if (res.data.message == "ok" )
        {
          ale1("Se ha cerrado sesión correctamente");
        } 
        else if (res.data.message == "no" )
        {
          notificacion("No existe un usuario logueado en el sistema");
        } 
      }).catch(error => { 
        notificacion("Ocurrio un error al realizar la petición")
        console.log(error); 
      });
    }
  }
    const ale1 = (txt) => {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3500,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: 'success',
            title: txt
        })
    }

    const ale2 = (text2) => {

        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: text2
        })

    }

    const notificacion = (txt) => {
        Swal.fire({
            position: 'center',
            icon: 'error',
            title: txt,
            showConfirmButton: false,
            timer: 2000
        })
    }
    return (
        <>
            <Toaster />
            <Navb />
            <Button className="botonE" onClick={formLogin2}>Iniciar sesión</Button>{' '}

            <Button className="botonE" onClick={doLogout}>Cerrar sesión</Button>{' '}
        </>
    );
}

export default Partit;
