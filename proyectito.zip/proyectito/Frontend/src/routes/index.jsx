import { createBrowserRouter } from "react-router-dom";

import CodeEditorWindow from "../LineNumberedTextEditor/CodeEditorWindow"

import House from "../House/House"
import Disk from "../Disko/Disko"
import Pant1 from "../Pantalla1/Pantalla1"
import Pant2 from "../Pantalla2/Pantalla2"
import Pant3 from "../Pantalla3/Pantalla3"
import Partit from "../Partit/Partit"

export const router = createBrowserRouter([
    {
        path: '/', 
        element: <House />
    },{

        path: '/editor', 
        element: <CodeEditorWindow />
    },{

        path: '/disco', 
        element: <Disk />
    },{
        path: '/PT1', 
        element: <Pant1 />
    },{

        path: '/PT2', 
        element: <Pant2 />
    },{

        path: '/PT3', 
        element: <Pant3 />
    },{

        path: '/part', 
        element: <Partit />
    }
])