import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import { useNavigate } from 'react-router-dom';
import './Navb.css'

function Navb() {
  return (
    <>
      <Navbar expand="lg" bg="dark" data-bs-theme="dark"  >
        <Container>
          <Navbar.Brand href="/">Home</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="/Pantalla1"><img src="https://img.icons8.com/fluency-systems-regular/38/ffffff/play--v1.png" alt='dd' />Ejecución Comandos</Nav.Link>
            <Nav.Link href="/Pantalla2"><img src="https://img.icons8.com/ios/36/ffffff/opened-folder.png" alt='s' />Exploración Archivos</Nav.Link>
            <Nav.Link href="/Pantalla3"><img src="https://img.icons8.com/external-justicon-lineal-justicon/38/ffffff/external-report-cryptocurrency-justicon-lineal-justicon.png" alt='d' />Reportes </Nav.Link>
          </Nav>
        </Container>
      </Navbar>
    </>
  );
}

export default Navb;