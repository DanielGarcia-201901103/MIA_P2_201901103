
import Navb from "../Nav/Navb.jsx"
import CodeEditorWindow from "../LineNumberedTextEditor/CodeEditorWindow.jsx"
const Pantalla1 = () => {
    return (
      <>
      <Navb/>
      <CodeEditorWindow/>
  </>
    );
  }
  
  export default Pantalla1;
  