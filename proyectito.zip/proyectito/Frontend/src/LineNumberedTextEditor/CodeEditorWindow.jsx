import React, { useState } from "react";
import Editor from "@monaco-editor/react";
import "./CodeEditorWindow.css";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import axios from 'axios';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

const CodeEditorWindow = () => {
  const API_PORT = "localhost:5000"
  const navigate = useNavigate();
  const [vcoman, setComandos] = useState("");
  const [outputValue, setOutputValue] = useState("");
  //const [imagen, setImagen] = useState('https://yakurefu.com/wp-content/uploads/2020/02/Chi_by_wallabby.jpg')
  const [inputValue, setInputValue] = useState("");
  //const [options, setOptions] = useState([]);
  //const [arrAux, setArrAux] = useState([]);
  const element0 = { text: inputValue }
  const element = { text: vcoman }
  //localStorage.setItem('current', userLogin);
  const handleEditorChange = (value) => {
    setInputValue(value);
  };


  const handleOpenFile = async (e) => {
    const file = e.target.files[0]; // Obtiene el archivo seleccionado por el usuario
    const fileContent = await readFileContent(file); // Lee el contenido del archivo
    setInputValue(fileContent); // Actualiza el estado con el contenido del archivo
  };

  const readFileContent = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (e) => reject(e);
      reader.readAsText(file);
    });
  };
  const handleRunCode = async (e) => {
    const toastId = toast.loading('Procesando...');

    axios.post('http://' + API_PORT + '/sendContent', element0).then(res => {
      console.log(res.data);
      setOutputValue(res.data.consola);
      if (res.data.graficas != null) {
        //cargarGraficas(res.data.graficas);
        localStorage.setItem('gggggoptions', JSON.stringify(res.data.graficas));
        //localStorage.setItem('gggggarrAux', arrAux);
        if (res.data.graficas.length > 0) {
          toast.success('Se han generado reportes', { duration: 2500 });
        }
      }
      toast.dismiss(toastId);
      toast.success('Se ha procesado con exito', { duration: 2000 });
      // setContentAST(res.data.graficaAst);
    });

  };
  const handleSubmit = () => {
    const toastId = toast.loading('Procesando...');

    axios.post('http://' + API_PORT + '/sendContent', element).then(res => {
      console.log(res.data);
      setOutputValue(res.data.consola);
      if (res.data.graficas != null) {
        //cargarGraficas(res.data.graficas);
        localStorage.setItem('gggggoptions', JSON.stringify(res.data.graficas));
        //localStorage('gggggarrAux', arrAux);
        if (res.data.graficas.length > 0) {
          toast.success('Se han generado reportes', { duration: 2500 });
        }
      }
      toast.dismiss(toastId);
      toast.success('Se ha procesado con exito', { duration: 2000 });
      // setContentAST(res.data.graficaAst);
    });
  }
  /*
  const cargarGraficas = (arr) => {
    setArrAux(arr);
    let arrTemp = arr.map(item => {
      return { value: item.graph, label: item.name }
    });
    setOptions(arrTemp);
  }
  */
  return (
    <>
      <Toaster />
      <div className="code-editor-container">
        <div className="code-editor-left">
          <h2>Entrada multiples comandos</h2>
          <Editor
            height="50vh"
            width={`100%`}
            value={inputValue}
            theme="vs-dark"
            defaultValue="# Ingresa los comandos"
            onChange={handleEditorChange}
          />
        </div>

        <div className="conjuntoBotones">
          <ButtonGroup aria-label="Basic example" >
            <Button className="gbotonIn" as="label" htmlFor="fileInput">Abrir Archivo</Button>{' '}
            <input id="fileInput" type="file" accept=".mia" style={{ display: 'none', borderradius: "5px" }} onChange={handleOpenFile} />
            <Button className="botonE" onClick={handleRunCode}>Enviar desde Entrada</Button>{' '}
          </ButtonGroup>
          <Form >
            <InputGroup size="lg" className="custom-input-group">
              <InputGroup.Text id="inputGroup-sizing-lg">$_ </InputGroup.Text>
              <Form.Control
                placeholder="Ingresa un comando"
                type="text"
                aria-label="Large"
                aria-describedby="inputGroup-sizing-sm"
                className="custom-input"
                onChange={e => setComandos(e.target.value)}
                value={vcoman}
                autoFocus
                required
              />
              <Button variant="primary" type="button" className="custom-submit-button" onClick={handleSubmit}>
                Enviar
              </Button>
            </InputGroup>
          </Form>

        </div>
        <div className="code-editor-right">
          <h2>Consola</h2>
          <textarea
            className="output-console"
            value={outputValue}
            readOnly
            cols={50}
            placeholder="Output"
          />
        </div>
      </div>

      <div className="movilizando">
        <div className="spinner">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div></div>


      <br></br>
    </>
  );
};

export default CodeEditorWindow;