import { Link } from "react-router-dom";
import Navb from "../Nav/Navb.jsx";
import { useState, useRef } from 'react';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import './pantalla2.css';
const Pantalla2 = () => {
  const API_PORT = "54.91.103.38:5000"
  //datadisk   hacer peticion hacia esa ruta
  const [diskList, setDiskList] = useState([]);
  /*const discs = [
    { name: "A.disc", path: "/discA" },
    { name: "B.disc", path: "/discB" },
    { name: "C.disc", path: "/discC" },
    { name: "A.disc B.disc C.disc", path: "/discAll" },
  ];
 */

  const handlegetLDisk = async (e) => {
    const toastId = toast.loading('Procesando...');

    axios.get('http://' + API_PORT + '/datadisk').then(res => {
      //console.log(res.data.lsdisk);
      if (res.data.lsdisk != null) {
        //cargarGraficas(res.data.graficas);
        setDiskList(res.data.lsdisk);
        //localStorage.setItem('gggggoptions', JSON.stringify(res.data.graficas));
        //localStorage.setItem('gggggarrAux', arrAux);
        if (res.data.lsdisk.length > 0) {
          toast.success('Se han obtenido los discos', { duration: 2500 });
        }
      }
      toast.dismiss(toastId);
      toast.success('Se ha procesado con exito', { duration: 2000 });
      // setContentAST(res.data.graficaAst);
    })
    .catch(error => {
      console.error("Error al obtener discos:", error);
      toast.dismiss(toastId);
      toast.error('Error al obtener discos', { duration: 2000 });
    });


  };

  const handleDiskClick = async (disk) => {
    localStorage.setItem('discoss', JSON.stringify(disk));
  };

  return (
    <>
      <Toaster />
      <Navb />
      <Button className="botonE" onClick={handlegetLDisk}>Obtener Discos</Button>{' '}
      <div className="button-container">
        {diskList.map((disc, index) => (
          <Link key={index} to={"/disko"}>
            <button className="custom-button" onClick={() => handleDiskClick(disc)}>
              <img src="./device-hdd-fill.svg" alt="Disk Icon" className="icon" />
              {disc.name}
            </button>
          </Link>
        ))}
      </div>
    </>
  );
}

export default Pantalla2;
