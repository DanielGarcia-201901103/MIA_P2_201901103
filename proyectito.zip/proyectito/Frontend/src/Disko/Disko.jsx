import { Link } from "react-router-dom";
import Navb from "../Nav/Navb.jsx";
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import toast, { Toaster } from 'react-hot-toast';
import axios from 'axios';
import "./Disko.css";
const Disko = () => {
    const API_PORT = "localhost:5000"
    const APIURL = `http://${API_PORT}`
    const [diskListP, setDiskListP] = useState([]);

    //dataParticion
    const handlegetData2 = () => {
        let disccc = localStorage.getItem('discoss'); // Obtener el string del localStorage
        let discc = JSON.parse(disccc); // Convertir el string JSON en un array
        let element0 = { text: discc.path }
        const toastId = toast.loading('Procesando...');

        axios.post('http://' + API_PORT + '/dataParticion', element0).then(res => {
            if (res.data.particionn != null) {
                    setDiskListP(res.data.particionn);
                if (res.data.particionn.length > 0) {
                    toast.success('Se han obtenido las particiones', { duration: 2500 });
                }
            }
            toast.dismiss(toastId);
            toast.success('Se ha procesado con exito', { duration: 2000 });
        });
    }

  const handleDiskClick2 = async () => {

    //localStorage.setItem('discoss', JSON.stringify(disk));
  };
    return (
        <>
            <Toaster />
            <Navb />
            <Button className="botonE" onClick={handlegetData2}>Obtener Particiones</Button>{' '}
            <div className="button-container">
                {diskListP.map((disc, index) => (
                        <Link key={index} to={"/partiti"}>
                        <button className="custom-button" onClick={() => handleDiskClick2()}>
                            <img src="./files.svg" alt="Disk Icon" className="icon" />
                            {disc.name}
                        </button>
                    </Link>
                ))}
            </div>
        </>
    );
}

export default Disko;