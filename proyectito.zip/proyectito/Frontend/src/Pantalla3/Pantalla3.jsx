import Select from 'react-select';
import { Graphviz } from 'graphviz-react';
import { useState, useRef } from 'react';
import Button from 'react-bootstrap/Button';
import Navb from "../Nav/Navb.jsx"
const Pantalla3 = () => {
  const [contAST, setContentAST] = useState(`digraph G { label="Sin reportesssss";}`);
  const [selectedOption, setSelectedOption] = useState(null);
  const [options, setOptions] = useState([]);
  const [arrAux, setArrAux] = useState([]);
  const ref = useRef(null);

  const handlegetData = () => {
    let graficasStr = localStorage.getItem('gggggoptions'); // Obtener el string del localStorage
    let graficas = JSON.parse(graficasStr); // Convertir el string JSON en un array
    setArrAux(graficas);
    let arrTemp = graficas.map(item => {
      return { value: item.graph, label: item.name }
    });
    setOptions(arrTemp);
  }

  const changeDot = (selectedOption) => {
    setSelectedOption(selectedOption);

    setContentAST(selectedOption.value);

  }

  const goReports = () => {
    ref.current.scrollIntoView({ behavior: 'smooth' })
  }
  /*
    const notificacionReporte = () => {
      toast('Aca puedes ver los reportes generados!',
        {
          icon: '👆',
          position: 'bottom-center',
          style: {
            borderRadius: '10px',
            background: '#333',
            color: '#fff',
          },
        }
      );
    }*/

  return (
    <>
      <Navb />
      <Button className="botonE" onClick={handlegetData}>Obtener datos</Button>{' '}
      <div ref={ref} id="reporteSimbolos" className='text-center p-4'>
        <div className="card text-black bg-dark mb-3">
          <div className="card-header"><h1 className="titleReports">Reportes</h1></div>

          <div className="card-body">
            <Select
              defaultValue={selectedOption}
              isSearchable={true}
              onChange={changeDot}
              options={options}
              theme={(theme) => ({
                ...theme,
                borderRadius: 0,
                colors: {
                  ...theme.colors,
                  primary25: '#9eded5',
                  primary: '#37bfad',
                },
              })}
            />
            <br></br><br></br>
            <table className="table table-dark table-striped">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Tipo</th>
                  <th>Ruta</th>
                </tr>
              </thead>
              <tbody>
                {
                  arrAux.map((element) => (
                  <tr key={element.id}>
                  <td>{element.name}</td>
                  <td>{element.type}</td>
                  <td>{element.path}</td>
                  </tr>
                  ))

                }
              </tbody>

            </table>

          </div>
        </div>
      </div>

      <div className='text-center p-4'>
        <div className="card text-black bg-white mb-1">

          <div className="card-body">
            <Graphviz
              options={{
                width: "100%",
                height: "1000px",
                zoom: true,
                fit: false
              }}
              dot={contAST} />
            <br /><br />
          </div>
        </div>
      </div>

    </>
  );
}

export default Pantalla3;
